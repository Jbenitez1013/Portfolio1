// src/components/DefaultLayout.js

import React from 'react';
import Header from './header.js';  // Common header for all pages
import Footer from './footer.js';  // Common footer for all pages

function DefaultLayout({ children }) {
  return (
    <>
      <Header />  {/* Appears on all pages */}
      <main>
        {children}  {/* Dynamic content for each page */}
      </main>
      <Footer />  {/* Appears on all pages */}
    </>
  );
}

export default DefaultLayout;
